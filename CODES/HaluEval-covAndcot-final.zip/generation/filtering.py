import json
import time
import argparse
import torch
from mistral_llm import model, tokenizer, stop_token_ids

# Check for GPU availability
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def call_mistral_model(messages):
    prompt = ""
    for message in messages:
        prompt += f"{message['role']}: {message['content']}\n"

    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}  # Move inputs to the device
    output = model.generate(**inputs, temperature=1.0, top_p=0.9, max_new_tokens=50, num_return_sequences=1)
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    response = response.replace(prompt, "").strip()
    return {"choices": [{"message": {"content": response}}]}

def chain_of_verification(knowledge, input_text, hallucinated_output, instruction):
    """
    Chain of Verification for QA, Dialogue, and Summarization tasks.
    """
    message = [
        {"role": "system", "content": "You are a verifier. Verify the accuracy of the given output based on the provided knowledge or context."},
        {"role": "user", "content": f"{instruction}\n\n#Knowledge/Context#: {knowledge}\n#Input#: {input_text}\n#Output#: {hallucinated_output}\n#Verification#: "}
    ]
    res = call_mistral_model(message)
    return res['choices'][0]['message']['content']

def get_qa_res(knowledge, question, answer1, answer2, instruction):
    message = [
        {"role": "system", "content": "You are an answer judge. Choose the better answer between Answer 1 and Answer 2."},
        {"role": "user", "content": f"{instruction}\n\n#Knowledge#: {knowledge}\n#Question#: {question}\n#Answer 1#: {answer1}\n#Answer 2#: {answer2}\n#Your Choice#: "}
    ]
    res = call_mistral_model(message)
    return res['choices'][0]['message']['content']

def get_dialogue_res(knowledge, dialog, response1, response2, instruction):
    message = [
        {"role": "system", "content": "You are a response judge. Choose the better response between Response 1 and Response 2."},
        {"role": "user", "content": f"{instruction}\n\n#Knowledge#: {knowledge}\n#Dialogue History#: {dialog}\n#Response 1#: {response1}\n#Response 2#: {response2}\n#Your Choice#: "}
    ]
    res = call_mistral_model(message)
    return res['choices'][0]['message']['content']

def get_summarization_res(document, summary1, summary2, instruction):
    message = [
        {"role": "system", "content": "You are a summary judge. Choose the better summary between Summary 1 and Summary 2."},
        {"role": "user", "content": f"{instruction}\n\n#Document#: {document}\n#Summary 1#: {summary1}\n#Summary 2#: {summary2}\n#Your Choice#: "}
    ]
    res = call_mistral_model(message)
    return res['choices'][0]['message']['content']

def dump_jsonl(data, output_path, append=False):
    mode = 'a+' if append else 'w'
    with open(output_path, mode, encoding='utf-8') as f:
        json_record = json.dumps(data, ensure_ascii=False)
        f.write(json_record + '\n')

def filtering_qa_dataset(file1, file2, instruction, output_path):
    with open(file1, 'r', encoding="utf-8") as f:
        data1 = [json.loads(line) for line in f]

    with open(file2, 'r', encoding="utf-8") as f:
        data2 = [json.loads(line) for line in f]

    print(f"Length of data1: {len(data1)}")
    print(f"Length of data2: {len(data2)}")

    min_length = min(len(data1), len(data2))

    for i in range(min_length):
        entry1 = data1[i]
        entry2 = data2[i]
        knowledge = entry1["knowledge"]
        question = entry1["question"]
        answer1 = entry1["hallucinated_answer"]
        answer2 = entry2["hallucinated_answer"]

        choice = get_qa_res(knowledge, question, answer1, answer2, instruction)
        selected_answer = answer1 if "Answer 1" in choice else answer2
        verification = chain_of_verification(knowledge, question, selected_answer, instruction)

        filtered_entry = {
            "knowledge": knowledge,
            "question": question,
            "hallucinated_answer": selected_answer,
            "verification": verification
        }
        dump_jsonl(filtered_entry, output_path, append=True)
        print(f"Sample {i} completed!")

def filtering_dialogue_dataset(file1, file2, instruction, output_path):
    with open(file1, 'r', encoding="utf-8") as f:
        data1 = [json.loads(line) for line in f]

    with open(file2, 'r', encoding="utf-8") as f:
        data2 = [json.loads(line) for line in f]

    print(f"Length of data1: {len(data1)}")
    print(f"Length of data2: {len(data2)}")

    min_length = min(len(data1), len(data2))

    for i in range(min_length):
        entry1 = data1[i]
        entry2 = data2[i]
        knowledge = entry1["knowledge"]
        dialog = entry1["dialogue_history"]
        response1 = entry1["hallucinated_response"]
        response2 = entry2["hallucinated_response"]

        choice = get_dialogue_res(knowledge, dialog, response1, response2, instruction)
        selected_response = response1 if "Response 1" in choice else response2
        verification = chain_of_verification(knowledge, dialog, selected_response, instruction)

        filtered_entry = {
            "knowledge": knowledge,
            "dialogue_history": dialog,
            "hallucinated_response": selected_response,
            "verification": verification
        }
        dump_jsonl(filtered_entry, output_path, append=True)
        print(f"Sample {i} completed!")

def filtering_summarization_dataset(file1, file2, instruction, output_path):
    with open(file1, 'r', encoding="utf-8") as f:
        data1 = [json.loads(line) for line in f]

    with open(file2, 'r', encoding="utf-8") as f:
        data2 = [json.loads(line) for line in f]

    print(f"Length of data1: {len(data1)}")
    print(f"Length of data2: {len(data2)}")

    min_length = min(len(data1), len(data2))

    for i in range(min_length):
        entry1 = data1[i]
        entry2 = data2[i]
        document = entry1["document"]
        summary1 = entry1["hallucinated_summary"]
        summary2 = entry2["hallucinated_summary"]

        choice = get_summarization_res(document, summary1, summary2, instruction)
        selected_summary = summary1 if "Summary 1" in choice else summary2
        verification = chain_of_verification(document, "", selected_summary, instruction)

        filtered_entry = {
            "document": document,
            "hallucinated_summary": selected_summary,
            "verification": verification
        }
        dump_jsonl(filtered_entry, output_path, append=True)
        print(f"Sample {i} completed!")

def main():
    parser = argparse.ArgumentParser(description="Filtering Script for QA, Dialogue, and Summarization with CoV")
    parser.add_argument("--task", type=str, required=True, choices=["qa", "dialogue", "summarization"], help="Task type: qa, dialogue, or summarization")
    parser.add_argument("--file1", type=str, required=True, help="Path to the first input file")
    parser.add_argument("--file2", type=str, required=True, help="Path to the second input file")
    parser.add_argument("--instruction", type=str, required=True, help="Instruction to provide to the model")
    parser.add_argument("--output_path", type=str, required=True, help="Path to the output file")

    args = parser.parse_args()

    if args.task == "qa":
        filtering_qa_dataset(args.file1, args.file2, args.instruction, args.output_path)
    elif args.task == "dialogue":
        filtering_dialogue_dataset(args.file1, args.file2, args.instruction, args.output_path)
    elif args.task == "summarization":
        filtering_summarization_dataset(args.file1, args.file2, args.instruction, args.output_path)
    else:
        print(f"Unknown task: {args.task}")

if __name__ == "__main__":
    main()
