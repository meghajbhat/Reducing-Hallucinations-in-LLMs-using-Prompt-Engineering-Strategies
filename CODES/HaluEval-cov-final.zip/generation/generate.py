import time
import json
import argparse
import csv
import os
import torch
from mistral_llm import model, tokenizer, stop_token_ids

# Check for GPU availability
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def call_mistral_model(messages):
    prompt = ""
    for message in messages:
        prompt += f"{message['role']}: {message['content']}\n"
    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(**inputs, temperature=1.0, top_p=0.9, max_new_tokens=50, num_return_sequences=1)
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    response = response.replace(prompt, "").strip()
    return {"choices": [{"message": {"content": response}}]}


def chain_of_verification(knowledge, input_text, hallucinated_output, instruction):
    message = [
        {"role": "system", "content": "You are a verifier. Verify the accuracy of the given output based on the provided knowledge or context."},
        {"role": "user", "content": f"{instruction}\n\n#Knowledge/Context#: {knowledge}\n#Input#: {input_text}\n#Output#: {hallucinated_output}\n#Verification#: "}
    ]
    res = call_mistral_model(message)
    return res['choices'][0]['message']['content']


# QA Task (untouched)
def get_qa_res(knowledge, question, answer, instruction, strategy):
    if strategy == "one-turn":
        prompt = f"{instruction}\n\n#Knowledge#: {knowledge}\n#Question#: {question}\n#Right Answer#: {answer}\n#Hallucinated Answer#: "
    elif strategy == "multi-turn":
        instruction_str = "\n".join([ins['content'] for ins in instruction])
        prompt = f"{instruction_str}\n\n#Knowledge#: {knowledge}\n#Question#: {question}\n#Right Answer#: {answer}\n#Hallucinated Answer#: "

    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(**inputs, temperature=1.0, top_p=0.9, max_new_tokens=20, num_return_sequences=1)
    hallucinated_answer = tokenizer.decode(output[0], skip_special_tokens=True)
    hallucinated_answer = hallucinated_answer.replace(prompt, "").strip()

    verification = chain_of_verification(knowledge, question, hallucinated_answer, instruction)
    return hallucinated_answer, verification


def generate_qa_dataset(seed_data, instruction, output_path, strategy):
    with open(seed_data, 'r', encoding="utf-8") as f:
        text = json.load(f)

    batch_size = 10
    num_samples = len(text)
    num_batches = (num_samples + batch_size - 1) // batch_size

    for i in range(num_batches):
        batch = text[i * batch_size:(i + 1) * batch_size]
        results = []

        for sample in batch:
            question = sample['question']
            answer = sample['answer']
            supporting_facts = sample['supporting_facts']
            context = sample['context']
            knowledge = ""
            for fact in supporting_facts:
                for para in context:
                    if para[0] == fact[0] and fact[1] < len(para[1]):
                        knowledge += para[1][fact[1]]

            hallucinated_answer, verification = get_qa_res(knowledge, question, answer, instruction, strategy)
            results.append({
                "knowledge": knowledge,
                "question": question,
                "right_answer": answer,
                "hallucinated_answer": hallucinated_answer,
                "verification": verification
            })

        dump_jsonl(results, output_path, append=True)
        print(f"Batch {i + 1}/{num_batches} completed!")


# ✅ Dialogue Task — One-Turn Fixed
def get_dialogue_res(knowledge, dialog, response, instruction, strategy):
    if strategy == "one-turn":
        prompt = f"{instruction.strip()}\n\n#Knowledge#: {knowledge.strip()}\n#Dialogue History#: {dialog.strip()}\n#True Response#: {response.strip()}\n#Hallucinated Response#:\n"
    elif strategy == "multi-turn":
        instruction_str = "\n".join([ins['content'] for ins in instruction])
        prompt = f"{instruction_str}\n\n#Knowledge#: {knowledge.strip()}\n#Dialogue History#: {dialog.strip()}\n#True Response#: {response.strip()}\n#Hallucinated Response#:\n"

    inputs = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=2048)
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(
        **inputs,
        temperature=1.0,
        top_p=0.9,
        max_new_tokens=60,
        num_return_sequences=1,
        eos_token_id=tokenizer.eos_token_id,
    )
    hallucinated_response = tokenizer.decode(output[0], skip_special_tokens=True)
    hallucinated_response = hallucinated_response.replace(prompt, "").strip()

    verification = chain_of_verification(knowledge, dialog, hallucinated_response, instruction)
    return hallucinated_response, verification


def generate_dialogue_dataset(seed_data, instruction, output_path, strategy):
    with open(seed_data, 'r', encoding="utf-8") as f:
        csv_reader = csv.DictReader(f)
        rows = list(csv_reader)

    batch_size = 10
    num_samples = len(rows)
    num_batches = (num_samples + batch_size - 1) // batch_size

    for batch_idx in range(num_batches):
        batch = rows[batch_idx * batch_size:(batch_idx + 1) * batch_size]
        results = []

        for i, row in enumerate(batch):
            try:
                messages = json.loads(row['Messages'])

                dialog, response, knowledge = "", "", ""
                for message in messages:
                    if message['type'] == "chat":
                        sender = "[Human]" if message['sender'] == "user" else "[Assistant]"
                        dialog += f"{sender}: {message['message']} "
                        if message['sender'] == "assistant":
                            response = message['message']
                    if "metadata" in message and "path" in message['metadata']:
                        knowledge += message['metadata']['path'][-1] + " "

                if not dialog.strip() or not response.strip() or not knowledge.strip():
                    continue

                hallucinated_response, verification = get_dialogue_res(
                    knowledge.strip(), dialog.strip(), response.strip(),
                    instruction if isinstance(instruction, list) else instruction.strip(),
                    strategy
                )

                results.append({
                    "knowledge": knowledge.strip(),
                    "dialogue_history": dialog.strip(),
                    "right_response": response.strip(),
                    "hallucinated_response": hallucinated_response.strip(),
                    "verification": verification
                })

            except json.JSONDecodeError as e:
                print(f"Error parsing Messages for row {batch_idx * batch_size + i + 1}: {e}")
                continue

        dump_jsonl(results, output_path, append=True)
        print(f"Batch {batch_idx + 1}/{num_batches} completed!")


# Summarization Task (untouched)
def get_summarization_res(text, summary, instruction, strategy):
    if strategy == "one-turn":
        prompt = f"{instruction}\n\n#Document#: {text}\n#Right Summary#: {summary}\n#Hallucinated Summary#: "
    elif strategy == "multi-turn":
        instruction_str = "\n".join([ins['content'] for ins in instruction])
        prompt = f"{instruction_str}\n\n#Document#: {text}\n#Right Summary#: {summary}\n#Hallucinated Summary#: "
    else:
        raise ValueError(f"Invalid strategy: {strategy}")

    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(**inputs, temperature=1.0, top_p=0.9, max_new_tokens=50, num_return_sequences=1)
    hallucinated_summary = tokenizer.decode(output[0], skip_special_tokens=True)
    hallucinated_summary = hallucinated_summary.replace(prompt, "").strip()

    return hallucinated_summary


def generate_summarization_dataset(seed_data, instruction, output_path, strategy):
    stories_dir = seed_data
    story_files = [f for f in os.listdir(stories_dir) if f.endswith('.story')]
    print(f"Total .story files found: {len(story_files)}")

    results = []

    for i, file_name in enumerate(story_files):
        file_path = os.path.join(stories_dir, file_name)
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read().strip().split('\n\n')
                document = content[0].strip() if len(content) > 0 else ""
                summary = content[1].strip() if len(content) > 1 else ""

                if not document or not summary:
                    print(f"Skipped file {file_name}: Missing document/summary.")
                    continue

                hallucinated_summary = get_summarization_res(document, summary, instruction, strategy)
                verification = chain_of_verification(document, summary, hallucinated_summary, instruction)

                result = {
                    "document": document,
                    "right_summary": summary,
                    "hallucinated_summary": hallucinated_summary,
                    "verification": verification
                }
                results.append(result)
                print(f"Processed file {i + 1}/{len(story_files)}: {file_name} | Result: {result}")

        except Exception as e:
            print(f"Error processing file {file_name}: {e}")
            continue

    if results:
        dump_jsonl(results, output_path)
        print(f"Summarization dataset generation completed! {len(results)} records written to {output_path}.")
    else:
        print("No results were generated. Check input files and logs for issues.")


# Utility
def dump_jsonl(data, output_path, append=False):
    mode = 'a+' if append else 'w'
    with open(output_path, mode, encoding='utf-8') as f:
        for record in data:
            json_record = json.dumps(record, ensure_ascii=False)
            f.write(json_record + '\n')


# Main
if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Hallucination Generation with CoV")
    parser.add_argument("--seed_data", required=True, help="The original dataset file")
    parser.add_argument("--task", required=True, choices=["qa", "dialogue", "summarization"], help="Task type")
    parser.add_argument("--strategy", required=True, choices=["one-turn", "multi-turn"], help="Strategy type")
    parser.add_argument("--output_path", required=True, help="Path to save the generated data")
    args = parser.parse_args()

    if args.strategy == "one-turn":
        instruction_file = f"{args.task}/{args.task}_{args.strategy}_instruction.txt"
        with open(instruction_file, 'r', encoding="utf-8") as f:
            instruction = f.read()
    elif args.strategy == "multi-turn":
        instruction_file = f"{args.task}/{args.task}_{args.strategy}_instruction.json"
        with open(instruction_file, 'r', encoding="utf-8") as f:
            instruction = [json.loads(line) for line in f.readlines()]

    if args.task == "qa":
        generate_qa_dataset(args.seed_data, instruction, args.output_path, args.strategy)
    elif args.task == "dialogue":
        generate_dialogue_dataset(args.seed_data, instruction, args.output_path, args.strategy)
    elif args.task == "summarization":
        generate_summarization_dataset(args.seed_data, instruction, args.output_path, args.strategy)
