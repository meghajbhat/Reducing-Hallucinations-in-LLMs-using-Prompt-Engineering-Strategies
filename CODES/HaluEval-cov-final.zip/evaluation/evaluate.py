import json
import time
import random
import argparse
import torch
from sklearn.metrics import precision_score, recall_score, f1_score
from mistral_llm import model, tokenizer

# Check for GPU availability
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def call_mistral_model(messages):
    """
    Calls the Mistral LLM model with the given messages and returns the response.
    """
    prompt = ""
    for message in messages:
        prompt += f"{message['role']}: {message['content']}\n"

    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(**inputs, temperature=1.0, top_p=0.9, max_new_tokens=50, num_return_sequences=1)
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    return {"choices": [{"message": {"content": response.replace(prompt, "").strip()}}]}

def cov(input_text, generated_output, instruction):
    """
    Implements Chain of Verification (COV) to validate generated outputs.
    """
    verification_prompt = (
        f"{instruction}\n\n"
        f"#Input#: {input_text}\n"
        f"#Generated Output#: {generated_output}\n"
        f"#Verification#: "
    )
    message = [
        {"role": "system", "content": "You are a verifier for validating outputs."},
        {"role": "user", "content": verification_prompt}
    ]

    while True:
        try:
            response = call_mistral_model(message)
            return response['choices'][0]['message']['content']
        except Exception as e:
            print(f"Error during verification: {e}")
            time.sleep(20)

def dump_jsonl(data, output_path, append=False):
    """
    Write list of objects to a JSON lines file.
    """
    mode = 'a+' if append else 'w'
    with open(output_path, mode, encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)
        f.write('\n')

def evaluation_qa_dataset(file, instruction, output_path):
    with open(file, 'r', encoding="utf-8") as f:
        data = [json.loads(line) for line in f]

    y_true, y_pred = [], []

    for i, entry in enumerate(data):
        knowledge = entry["knowledge"]
        question = entry["question"]
        hallucinated_answer = entry["hallucinated_answer"]
        right_answer = entry.get("right_answer", "")

        answer = hallucinated_answer if random.random() > 0.5 else right_answer
        ground_truth = "Yes" if answer == hallucinated_answer else "No"
        y_true.append(1 if ground_truth == "Yes" else 0)

        feedback = cov(question, answer, instruction)
        judgement = "Yes" if "correct" in feedback.lower() and "incorrect" not in feedback.lower() else "No"
        y_pred.append(1 if judgement == "Yes" else 0)

        result = {
            "knowledge": knowledge,
            "question": question,
            "answer": answer,
            "ground_truth": ground_truth,
            "judgement": judgement,
            "verification": feedback
        }
        dump_jsonl(result, output_path, append=True)
        print(f"Sample {i} completed! Ground truth: {ground_truth}, Judgement: {judgement}")

    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    accuracy = sum(1 for true, pred in zip(y_true, y_pred) if true == pred) / len(y_true)

    print(f'Precision: {precision:.2f}')
    print(f'Recall: {recall:.2f}')
    print(f'F1 Score: {f1:.2f}')
    print(f'Accuracy: {accuracy:.2f}')

def evaluation_dialogue_dataset(file, instruction, output_path):
    with open(file, 'r', encoding="utf-8") as f:
        data = [json.loads(line) for line in f]

    y_true, y_pred = [], []

    for i, entry in enumerate(data):
        knowledge = entry["knowledge"]
        dialog = entry["dialogue_history"]
        hallucinated_response = entry["hallucinated_response"]
        right_response = entry.get("right_response", "")

        response = hallucinated_response if random.random() > 0.5 else right_response
        ground_truth = "Yes" if response == hallucinated_response else "No"
        y_true.append(1 if ground_truth == "Yes" else 0)

        feedback = cov(dialog, response, instruction)
        judgement = "Yes" if "correct" in feedback.lower() and "incorrect" not in feedback.lower() else "No"
        y_pred.append(1 if judgement == "Yes" else 0)

        result = {
            "knowledge": knowledge,
            "dialogue_history": dialog,
            "response": response,
            "ground_truth": ground_truth,
            "judgement": judgement,
            "verification": feedback
        }
        dump_jsonl(result, output_path, append=True)
        print(f"Sample {i} completed! Ground truth: {ground_truth}, Judgement: {judgement}")

    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    accuracy = sum(1 for true, pred in zip(y_true, y_pred) if true == pred) / len(y_true)

    print(f'Precision: {precision:.2f}')
    print(f'Recall: {recall:.2f}')
    print(f'F1 Score: {f1:.2f}')
    print(f'Accuracy: {accuracy:.2f}')

def main():
    parser = argparse.ArgumentParser(description="Evaluate Mistral LLM on QA and Dialogue tasks.")
    parser.add_argument("--file", type=str, required=True, help="Path to the dataset file")
    parser.add_argument("--instruction", type=str, required=True, help="Instruction to be used")
    parser.add_argument("--output_path", type=str, required=True, help="Output path for the evaluated dataset")
    parser.add_argument("--task_type", type=str, required=True, choices=['qa', 'dialogue'], help="Type of task: qa or dialogue")

    args = parser.parse_args()

    if args.task_type == 'qa':
        evaluation_qa_dataset(args.file, args.instruction, args.output_path)
    elif args.task_type == 'dialogue':
        evaluation_dialogue_dataset(args.file, args.instruction, args.output_path)

if __name__ == "__main__":
    main()
