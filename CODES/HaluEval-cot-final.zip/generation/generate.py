import time
import json
import argparse
import csv
import os
import torch
from mistral_llm import model, tokenizer, stop_token_ids

# Check for GPU availability
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def append_chain_of_thought(prompt, cot_msg):
    return f"{prompt}\n#Reasoning#: {cot_msg}"

def get_qa_res(knowledge, question, answer, instruction, strategy):
    if strategy == "one-turn":
        if isinstance(instruction, str):
            base_prompt = f"{instruction}\n\n#Knowledge#: {knowledge}\n#Question#: {question}\n#Right Answer#: {answer}\n#Hallucinated Answer#: "
        else:
            raise TypeError("The instruction must be a str!")
    elif strategy == "multi-turn":
        if isinstance(instruction, list):
            instruction_str = "\n".join([ins['content'] for ins in instruction])
            base_prompt = f"{instruction_str}\n\n#Knowledge#: {knowledge}\n#Question#: {question}\n#Right Answer#: {answer}\n#Hallucinated Answer#: "
        else:
            raise TypeError("The instruction must be a list of dictionaries!")

    prompt_with_cot = append_chain_of_thought(base_prompt, "Let's think step by step to come up with the answer.")
    inputs = tokenizer(prompt_with_cot, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(**inputs, temperature=1.0, top_p=0.9, max_new_tokens=20, num_return_sequences=1)
    hallucinated_answer = tokenizer.decode(output[0], skip_special_tokens=True)
    hallucinated_answer = hallucinated_answer.replace(prompt_with_cot, "").strip()
    return hallucinated_answer


def get_dialogue_res(knowledge, dialog, response, instruction, strategy):
    if strategy == "one-turn":
        if isinstance(instruction, str):
            base_prompt = f"{instruction}\n\n#Knowledge#: {knowledge}\n#Dialogue History#: {dialog}\n#True Response#: {response}\n#Hallucinated Response#: "
        else:
            raise TypeError("The instruction must be a str!")
    elif strategy == "multi-turn":
        if isinstance(instruction, list):
            instruction_str = "\n".join([ins['content'] for ins in instruction])
            base_prompt = f"{instruction_str}\n\n#Knowledge#: {knowledge}\n#Dialogue History#: {dialog}\n#True Response#: {response}\n#Hallucinated Response#: "
        else:
            raise TypeError("The instruction must be a list of dictionaries!")

    prompt_with_cot = append_chain_of_thought(base_prompt, "Let's think step by step to form a good response.")
    inputs = tokenizer(prompt_with_cot, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(**inputs, temperature=1.0, top_p=0.9, max_new_tokens=20, num_return_sequences=1)
    hallucinated_response = tokenizer.decode(output[0], skip_special_tokens=True)
    hallucinated_response = hallucinated_response.replace(prompt_with_cot, "").strip()
    return hallucinated_response


def get_summarization_res(text, summary, instruction, strategy):
    if strategy == "one-turn":
        if isinstance(instruction, str):
            base_prompt = f"{instruction}\n\n#Document#: {text}\n#Right Summary#: {summary}\n#Hallucinated Summary#: "
        else:
            raise TypeError("The instruction must be a str!")
    elif strategy == "multi-turn":
        if isinstance(instruction, list):
            instruction_str = "\n".join([ins['content'] for ins in instruction])
            base_prompt = f"{instruction_str}\n\n#Document#: {text}\n#Right Summary#: {summary}\n#Hallucinated Summary#: "
        else:
            raise TypeError("The instruction must be a list of dictionaries!")

    prompt_with_cot = append_chain_of_thought(base_prompt, "Let's think step by step to create a concise summary.")
    inputs = tokenizer(prompt_with_cot, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(**inputs, temperature=1.0, top_p=0.9, max_new_tokens=20, num_return_sequences=1)
    hallucinated_summary = tokenizer.decode(output[0], skip_special_tokens=True)
    hallucinated_summary = hallucinated_summary.replace(prompt_with_cot, "").strip()
    return hallucinated_summary


def generate_qa_dataset(seed_data, instruction, output_path, strategy):
    with open(seed_data, 'r', encoding="utf-8") as f:
        text = json.load(f)

        batch_size = 10
        num_samples = len(text)
        num_batches = (num_samples + batch_size - 1) // batch_size

        for i in range(num_batches):
            batch = text[i * batch_size:(i + 1) * batch_size]
            results = []

            for sample in batch:
                question = sample['question']
                answer = sample['answer']
                supporting_facts = sample['supporting_facts']
                context = sample['context']
                knowledge = ""
                for fact in supporting_facts:
                    for para in context:
                        if para[0] == fact[0] and fact[1] < len(para[1]):
                            knowledge += para[1][fact[1]]

                hallucinated_answer = get_qa_res(knowledge, question, answer, instruction, strategy)
                results.append({
                    "knowledge": knowledge,
                    "question": question,
                    "right_answer": answer,
                    "hallucinated_answer": hallucinated_answer
                })

            dump_jsonl(results, output_path, append=True)
            print(f"Batch {i + 1} completed!")


def generate_dialogue_dataset(seed_data, instruction, output_path, strategy):
    with open(seed_data, 'r', encoding="utf-8") as f:
        csv_reader = csv.DictReader(f)
        rows = list(csv_reader)

    batch_size = 10
    num_samples = len(rows)
    num_batches = (num_samples + batch_size - 1) // batch_size

    for batch_idx in range(num_batches):
        batch = rows[batch_idx * batch_size:(batch_idx + 1) * batch_size]
        results = []

        for i, row in enumerate(batch):
            try:
                messages = json.loads(row['Messages'])
                dialog, response, knowledge = "", "", ""
                for message in messages:
                    if message['type'] == "chat":
                        sender = "[Human]" if message['sender'] == "user" else "[Assistant]"
                        dialog += f"{sender}: {message['message']} "
                        if message['sender'] == "assistant":
                            response = message['message']
                    if "metadata" in message and "path" in message['metadata']:
                        knowledge += message['metadata']['path'][-1] + " "

                if not dialog.strip() or not response.strip() or not knowledge.strip():
                    continue

                hallucinated_response = get_dialogue_res(
                    knowledge.strip(), dialog.strip(), response.strip(), instruction, strategy
                )
                results.append({
                    "knowledge": knowledge.strip(),
                    "dialogue_history": dialog.strip(),
                    "right_response": response.strip(),
                    "hallucinated_response": hallucinated_response.strip()
                })

            except json.JSONDecodeError as e:
                print(f"Error parsing Messages for row {batch_idx * batch_size + i + 1}: {e}")
                continue

        dump_jsonl(results, output_path, append=True)
        print(f"Batch {batch_idx + 1}/{num_batches} completed!")


def generate_summarization_dataset(seed_data, instruction, output_path, strategy):
    stories_dir = seed_data
    story_files = [f for f in os.listdir(stories_dir) if f.endswith('.story')]
    print(f"Total .story files found: {len(story_files)}")

    for i, file_name in enumerate(story_files):
        file_path = os.path.join(stories_dir, file_name)
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read().strip().split('\n\n')
                document = content[0].strip() if len(content) > 0 else "No document"
                summary = content[1].strip() if len(content) > 1 else "No summary"

                if not document or not summary:
                    continue

                hallucinated_summary = get_summarization_res(document, summary, instruction, strategy)
                data = {
                    "document": document,
                    "right_summary": summary,
                    "hallucinated_summary": hallucinated_summary,
                }

                with open(output_path, 'a+', encoding='utf-8') as out_file:
                    json.dump(data, out_file, ensure_ascii=False)
                    out_file.write('\n')

                print(f"Sample {i + 1} completed!")

        except Exception as e:
            print(f"Error processing file {file_name}: {e}")
            continue


def dump_jsonl(data, output_path, append=False):
    mode = 'a+' if append else 'w'
    with open(output_path, mode, encoding='utf-8') as f:
        for record in data:
            json_record = json.dumps(record, ensure_ascii=False)
            f.write(json_record + '\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Hallucination Generation with Chain of Thought")
    parser.add_argument("--seed_data", required=True, help="The original dataset file")
    parser.add_argument("--task", required=True, choices=["qa", "dialogue", "summarization"], help="Task type")
    parser.add_argument("--strategy", required=True, choices=["one-turn", "multi-turn"], help="Strategy type")
    parser.add_argument("--output_path", required=True, help="Path to save the generated data")
    args = parser.parse_args()

    if args.strategy == "one-turn":
        instruction_file = f"{args.task}/{args.task}_{args.strategy}_instruction.txt"
        with open(instruction_file, 'r', encoding="utf-8") as f:
            instruction = f.read()
    elif args.strategy == "multi-turn":
        instruction_file = f"{args.task}/{args.task}_{args.strategy}_instruction.json"
        with open(instruction_file, 'r', encoding="utf-8") as f:
            instruction = [json.loads(line) for line in f.readlines()]

    if args.task == "qa":
        generate_qa_dataset(args.seed_data, instruction, args.output_path, args.strategy)
    elif args.task == "dialogue":
        generate_dialogue_dataset(args.seed_data, instruction, args.output_path, args.strategy)
    elif args.task == "summarization":
        generate_summarization_dataset(args.seed_data, instruction, args.output_path, args.strategy)
