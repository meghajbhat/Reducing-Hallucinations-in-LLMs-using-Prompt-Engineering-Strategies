import json
import time
import random
import argparse
import torch
from mistral_llm import model, tokenizer, stop_token_ids

# Check for GPU availability
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def call_mistral_model(messages):
    prompt = ""
    for message in messages:
        prompt += f"{message['role']}: {message['content']}\n"

    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(**inputs, temperature=0.7, top_p=0.9, max_new_tokens=150, num_return_sequences=1)
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    response = response.replace(prompt, "").strip()
    return {"choices": [{"message": {"content": response}}]}


def get_qa_res(knowledge, question, answer1, answer2, instruction):
    message = [
        {"role": "system", "content": "You are an answer judge. Think step by step and compare both answers based on factual correctness and relevance. Your final decision MUST be: 'The best answer is Answer 1.' or 'The best answer is Answer 2.'"},
        {"role": "user", "content": instruction +
                              "\n\n#Knowledge#: " + knowledge +
                              "\n#Question#: " + question +
                              "\n#Answer 1#: " + answer1 +
                              "\n#Answer 2#: " + answer2 +
                              "\n\nThink step-by-step before making your decision." +
                              "\n#Your Choice#: "}
    ]

    while True:
        try:
            res = call_mistral_model(message)
            if res:
                return res['choices'][0]['message']['content']
            else:
                return "Error: No response from Mistral model"
        except Exception as e:
            print(f"Error processing request to Mistral model: {e}")
            time.sleep(20)


def get_dialogue_res(knowledge, dialog, response1, response2, instruction):
    message = [
        {"role": "system", "content": "You are a response judge. Analyze each response in terms of coherence, relevance to the dialogue history, and consistency with the knowledge. Think step-by-step and then conclude with 'The best response is Response 1.' or 'The best response is Response 2.'"},
        {"role": "user", "content": instruction +
                              "\n\n#Knowledge#: " + knowledge +
                              "\n#Dialogue History#: " + dialog +
                              "\n#Response 1#: " + response1 +
                              "\n#Response 2#: " + response2 +
                              "\n\nThink through each response carefully." +
                              "\n#Your Choice#: "}
    ]

    while True:
        try:
            res = call_mistral_model(message)
            if res:
                return res['choices'][0]['message']['content'].strip()
            else:
                return "Error: No response from Mistral model"
        except Exception as e:
            print(f"Error processing request to Mistral model: {e}")
            time.sleep(20)


def get_summarization_res(document, summary1, summary2, instruction):
    message = [
        {"role": "system", "content": "You are a summary judge. Evaluate the summaries for coverage, coherence, and faithfulness to the document. Think step-by-step. Then reply with ONLY: 'The best summary is Summary 1.' or 'The best summary is Summary 2.'"},
        {"role": "user", "content": instruction +
                              "\n\n#Document#: " + document +
                              "\n#Summary 1#: " + summary1 +
                              "\n#Summary 2#: " + summary2 +
                              "\n\nThink through the summaries before making your decision." +
                              "\n#Your Choice#: "}
    ]

    while True:
        try:
            res = call_mistral_model(message)
            if res:
                return res['choices'][0]['message']['content'].strip()
            else:
                return "Error: No response from Mistral model"
        except Exception as e:
            print(f"Error processing request to Mistral model: {e}")
            time.sleep(20)


def dump_jsonl(data, output_path, append=False):
    mode = 'a+' if append else 'w'
    with open(output_path, mode, encoding='utf-8') as f:
        json_record = json.dumps(data, ensure_ascii=False)
        f.write(json_record + '\n')


def filtering_qa_dataset(file1, file2, instruction, output_path):
    with open(file1, 'r', encoding="utf-8") as f:
        data1 = [json.loads(line) for line in f]

    with open(file2, 'r', encoding="utf-8") as f:
        data2 = [json.loads(line) for line in f]

    min_length = min(len(data1), len(data2))
    print(f"Length of data1: {len(data1)}, data2: {len(data2)}")

    for i in range(min_length):
        entry1 = data1[i]
        entry2 = data2[i]
        knowledge = entry1["knowledge"]
        question = entry1["question"]
        answer1 = entry1["hallucinated_answer"]
        answer2 = entry2["hallucinated_answer"]
        right_ans = entry1["right_answer"]

        ans = "The best answer is Answer 2."

        if answer1 != answer2:
            for _ in range(5):
                ans = get_qa_res(knowledge, question, answer1, answer2, instruction)
                if "Answer 1" in ans or "Answer 2" in ans:
                    break
            else:
                print(f"Sample {i} fallback to Answer 2")

        hallucinated = answer1 if "1" in ans else answer2
        result = {"knowledge": knowledge, "question": question, "right_answer": right_ans, "hallucinated_answer": hallucinated}
        dump_jsonl(result, output_path, append=True)
        print(f"QA Sample {i} completed!")


def filtering_dialogue_dataset(file1, file2, instruction, output_path):
    with open(file1, 'r', encoding="utf-8") as f:
        data1 = [json.loads(line) for line in f]

    with open(file2, 'r', encoding="utf-8") as f:
        data2 = [json.loads(line) for line in f]

    min_length = min(len(data1), len(data2))
    print(f"Length of data1: {len(data1)}, data2: {len(data2)}")

    for i in range(min_length):
        entry1 = data1[i]
        entry2 = data2[i]
        knowledge = entry1["knowledge"]
        dialog = entry1["dialogue_history"]
        right_response = entry1["right_response"]
        response1 = entry1["hallucinated_response"]
        response2 = entry2["hallucinated_response"]

        if response1 == response2:
            res = random.choice(["The best response is Response 1.", "The best response is Response 2."])
        else:
            for _ in range(5):
                res = get_dialogue_res(knowledge, dialog, response1, response2, instruction)
                print(f"Sample {i} response: {res}")
                if "Response 1" in res or "Response 2" in res:
                    break
            else:
                print(f"Sample {i} failed after 5 attempts, using Response 2 as fallback")
                res = "The best response is Response 2."

        hallucinated = response1 if "1" in res else response2
        result = {"knowledge": knowledge, "dialogue_history": dialog, "right_response": right_response, "hallucinated_response": hallucinated}
        dump_jsonl(result, output_path, append=True)
        print(f"Dialogue Sample {i} completed!")


def filtering_summarization_dataset(file1, file2, instruction, output_path):
    with open(file1, 'r', encoding="utf-8") as f:
        data1 = [json.loads(line) for line in f]

    with open(file2, 'r', encoding="utf-8") as f:
        data2 = [json.loads(line) for line in f]

    min_length = min(len(data1), len(data2))
    print(f"Length of data1: {len(data1)}, data2: {len(data2)}")

    for i in range(min_length):
        entry1 = data1[i]
        entry2 = data2[i]
        document = entry1["document"]
        summary1 = entry1["hallucinated_summary"]
        summary2 = entry2["hallucinated_summary"]
        right_summary = entry1["right_summary"]

        if summary1 == summary2:
            res = random.choice(["The best summary is Summary 1.", "The best summary is Summary 2."])
        else:
            for _ in range(5):
                res = get_summarization_res(document, summary1, summary2, instruction)
                print(f"Sample {i} response: {res}")
                if "Summary 1" in res or "Summary 2" in res:
                    break
            else:
                print(f"Sample {i} failed after 5 attempts, skipping")
                continue

        hallucinated = summary1 if "1" in res else summary2
        result = {"document": document, "right_summary": right_summary, "hallucinated_summary": hallucinated}
        dump_jsonl(result, output_path, append=True)
        print(f"Summarization Sample {i} completed!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Filter dataset using a model judge")
    parser.add_argument("--file1", required=True)
    parser.add_argument("--file2", required=True)
    parser.add_argument("--instruction", required=True)
    parser.add_argument("--output_path", required=True)
    parser.add_argument("--task_type", choices=["qa", "dialogue", "summarization"], required=True)
    args = parser.parse_args()

    if args.task_type == "qa":
        filtering_qa_dataset(args.file1, args.file2, args.instruction, args.output_path)
    elif args.task_type == "dialogue":
        filtering_dialogue_dataset(args.file1, args.file2, args.instruction, args.output_path)
    elif args.task_type == "summarization":
        filtering_summarization_dataset(args.file1, args.file2, args.instruction, args.output_path)
