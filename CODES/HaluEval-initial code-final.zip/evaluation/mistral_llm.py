import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

model_name = 'filipealmeida/Mistral-7B-Instruct-v0.1-sharded'

def load_quantized_model(model_name: str):
    """
    Load a quantized model with the specified model name.

    :param model_name: Name or path of the model to be loaded.
    :return: Loaded quantized model.
    """
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_use_double_quant=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16
    )

    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype=torch.float16,
        quantization_config=bnb_config,
        device_map='auto',
        use_cache=True
    )

    return model

def initialize_tokenizer(model_name: str):
    """
    Initialize the tokenizer with the specified model name.

    :param model_name: Name or path of the model for tokenizer initialization.
    :return: Initialized tokenizer.
    """
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    tokenizer.bos_token_id = 1  # Set beginning of sentence token id
    return tokenizer

# Load the model and tokenizer
model = load_quantized_model(model_name)
tokenizer = initialize_tokenizer(model_name)
stop_token_ids = [0]

def generate_response(prompt):
    """
    Generate a response from the model for the given prompt.

    :param prompt: The input prompt to generate a response for.
    :return: Generated response.
    """
    inputs = tokenizer(prompt, return_tensors="pt")
    output = model.generate(**inputs, temperature=1.0, max_new_tokens=2048, num_return_sequences=1)
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    return response

def generate_prompt(instruction, knowledge, input_text, task_type):
    """
    Generate a prompt for the model based on the given instruction, knowledge, input text, and task type.

    :param instruction: The instruction for the model.
    :param knowledge: The knowledge context for the model.
    :param input_text: The input text for the model.
    :param task_type: The type of task (e.g., "Answer", "Response", "Summary").
    :return: Generated prompt.
    """
    return f"{instruction}\n\n#Knowledge#: {knowledge}\n#{task_type} Input#: {input_text}\n#Hallucinated {task_type}#: "
