import json
import time
import random
import argparse
import torch
from sklearn.metrics import precision_score, recall_score, f1_score
from mistral_llm import model, tokenizer, stop_token_ids

# Check for GPU availability
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Mocking the Mistral model call for this example
def call_mistral_model(messages):
    # Simulate feedback responses for testing
    prompt = ""
    for message in messages:
        prompt += f"{message['role']}: {message['content']}\n"
    
    # Example feedback for testing
    if "British" in prompt or "Crambidae" in prompt or "2006" in prompt:
        response = "This answer is correct."
    else:
        response = "This answer is incorrect."

    return {"choices": [{"message": {"content": response}}]}

# QA evaluation function
def get_qa_response(question, answer, instruction):
    message = [
        {"role": "system", "content": "You are an answer judge. Provide feedback based on the given answer."},
        {"role": "user", "content": instruction +
                              f"\n\n#Question#: {question}\n#Answer#: {answer}\n#Your Feedback#: "}
    ]

    while True:
        try:
            res = call_mistral_model(message)
            if res:
                return res['choices'][0]['message']['content']
            else:
                return "Error: No response from Mistral model"
        except Exception as e:
            print(f"Error processing request to Mistral model: {e}")
            time.sleep(20)

# Dialogue evaluation function
def get_dialogue_response(dialog, response, instruction):
    message = [
        {"role": "system", "content": "You are a response judge. Provide feedback based on the given response."},
        {"role": "user", "content": instruction +
                              f"\n\n#Dialogue History#: {dialog}\n#Response#: {response}\n#Your Feedback#: "}
    ]

    while True:
        try:
            res = call_mistral_model(message)
            if res:
                return res['choices'][0]['message']['content']
            else:
                return "Error: No response from Mistral model"
        except Exception as e:
            print(f"Error processing request to Mistral model: {e}")
            time.sleep(20)

# Summarization evaluation function
def get_summarization_response(document, summary, instruction):
    message = [
        {"role": "system", "content": "You are a summary judge. Provide feedback based on the given summary."},
        {"role": "user", "content": instruction +
                              f"\n\n#Document#: {document}\n#Summary#: {summary}\n#Your Feedback#: "}
    ]

    while True:
        try:
            res = call_mistral_model(message)
            if res:
                return res['choices'][0]['message']['content']
            else:
                return "Error: No response from Mistral model"
        except Exception as e:
            print(f"Error processing request to Mistral model: {e}")
            time.sleep(20)

def dump_jsonl(data, output_path, append=False):
    mode = 'a+' if append else 'w'
    with open(output_path, mode, encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)
        f.write('\n')

# QA dataset evaluation
def evaluation_qa_dataset(file, instruction, output_path):
    with open(file, 'r', encoding="utf-8") as f:
        data = [json.loads(line) for line in f]

    y_true = []
    y_pred = []
    seen_questions = set()

    for i, entry in enumerate(data):
        knowledge = entry["knowledge"]
        question = entry["question"]

        if question in seen_questions:
            continue

        seen_questions.add(question)

        hallucinated_answer = entry["hallucinated_answer"]
        right_answer = entry.get("right_answer", "")

        if random.random() > 0.5:
            answer = hallucinated_answer
            ground_truth = "Yes"
            y_true.append(1)
        else:
            answer = right_answer
            ground_truth = "No"
            y_true.append(0)

        feedback = get_qa_response(question, answer, instruction)
        judgement = "Yes" if "correct" in feedback.lower() and "incorrect" not in feedback.lower() else "No"
        y_pred.append(1 if judgement == "Yes" else 0)

        result = {"knowledge": knowledge, "question": question, "answer": answer, "ground_truth": ground_truth, "judgement": judgement}
        dump_jsonl(result, output_path, append=True)

    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    accuracy = sum(1 for true, pred in zip(y_true, y_pred) if true == pred) / len(y_true)

    print(f'Precision: {precision:.2f}')
    print(f'Recall: {recall:.2f}')
    print(f'F1 Score: {f1:.2f}')
    print(f'Accuracy: {accuracy:.2f}')

# Dialogue dataset evaluation
def evaluation_dialogue_dataset(file, instruction, output_path):
    with open(file, 'r', encoding="utf-8") as f:
        data = [json.loads(line) for line in f]

    y_true = []
    y_pred = []

    for i, entry in enumerate(data):
        knowledge = entry["knowledge"]
        dialog = entry["dialogue_history"]

        hallucinated_response = entry["hallucinated_response"]
        right_response = entry.get("right_response", "")

        if random.random() > 0.5:
            response = hallucinated_response
            ground_truth = "Yes"
            y_true.append(1)
        else:
            response = right_response
            ground_truth = "No"
            y_true.append(0)

        feedback = get_dialogue_response(dialog, response, instruction)
        judgement = "Yes" if "correct" in feedback.lower() and "incorrect" not in feedback.lower() else "No"
        y_pred.append(1 if judgement == "Yes" else 0)

        result = {"knowledge": knowledge, "dialogue_history": dialog, "response": response, "ground_truth": ground_truth, "judgement": judgement}
        dump_jsonl(result, output_path, append=True)

    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    accuracy = sum(1 for true, pred in zip(y_true, y_pred) if true == pred) / len(y_true)

    print(f'Precision: {precision:.2f}')
    print(f'Recall: {recall:.2f}')
    print(f'F1 Score: {f1:.2f}')
    print(f'Accuracy: {accuracy:.2f}')

# Summarization dataset evaluation
def evaluation_summarization_dataset(file, instruction, output_path):
    with open(file, 'r', encoding="utf-8") as f:
        data = [json.loads(line) for line in f]

    y_true = []
    y_pred = []

    for i, entry in enumerate(data):
        document = entry["document"]

        hallucinated_summary = entry["hallucinated_summary"]
        right_summary = entry.get("right_summary", "")

        if random.random() > 0.5:
            summary = hallucinated_summary
            ground_truth = "Yes"
            y_true.append(1)
        else:
            summary = right_summary
            ground_truth = "No"
            y_true.append(0)

        feedback = get_summarization_response(document, summary, instruction)
        judgement = "Yes" if "correct" in feedback.lower() and "incorrect" not in feedback.lower() else "No"
        y_pred.append(1 if judgement == "Yes" else 0)

        result = {"document": document, "summary": summary, "ground_truth": ground_truth, "judgement": judgement}
        dump_jsonl(result, output_path, append=True)

    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    accuracy = sum(1 for true, pred in zip(y_true, y_pred) if true == pred) / len(y_true)

    print(f'Precision: {precision:.2f}')
    print(f'Recall: {recall:.2f}')
    print(f'F1 Score: {f1:.2f}')
    print(f'Accuracy: {accuracy:.2f}')

def main():
    parser = argparse.ArgumentParser(description="Evaluate Mistral LLM on various tasks.")
    parser.add_argument("--file", type=str, required=True, help="Path to the dataset file")
    parser.add_argument("--instruction", type=str, required=True, help="Instruction to be used")
    parser.add_argument("--output_path", type=str, required=True, help="Output path for the evaluated dataset")
    parser.add_argument("--task_type", type=str, required=True, choices=['qa', 'dialogue', 'summarization'], help="Type of task (qa, dialogue, summarization)")

    args = parser.parse_args()

    if args.task_type == 'qa':
        evaluation_qa_dataset(args.file, args.instruction, args.output_path)
    elif args.task_type == 'dialogue':
        evaluation_dialogue_dataset(args.file, args.instruction, args.output_path)
    elif args.task_type == 'summarization':
        evaluation_summarization_dataset(args.file, args.instruction, args.output_path)

if __name__ == "__main__":
    main()
