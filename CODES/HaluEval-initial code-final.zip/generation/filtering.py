import json
import time
import random
import argparse
import torch
from mistral_llm import model, tokenizer, stop_token_ids

# Check for GPU availability
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def call_mistral_model(messages):
    prompt = ""
    for message in messages:
        prompt += f"{message['role']}: {message['content']}\n"
        
    inputs = tokenizer(prompt, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}
    output = model.generate(**inputs, temperature=0.7, top_p=0.9, max_new_tokens=50, num_return_sequences=1)
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    response = response.replace(prompt, "").strip()
    
    return {"choices": [{"message": {"content": response}}]}


def get_qa_res(knowledge, question, answer1, answer2, instruction):
    message = [
        {"role": "system", "content": "You are an answer judge. You MUST select an answer from the provided two answers. The answer you provided is \"The best answer is Answer 1.\" or \"The best answer is Answer 2.\""},
        {"role": "user", "content": instruction +
                              "\n\n#Knowledge#: " + knowledge +
                              "\n#Question#: " + question +
                              "\n#Answer 1#: " + answer1 +
                              "\n#Answer 2#: " + answer2 +
                              "\n#Your Choice#: "}
    ]

    while True:
        try:
            res = call_mistral_model(message)
            if res:
                return res['choices'][0]['message']['content']
            else:
                return "Error: No response from Mistral model"
        except Exception as e:
            print(f"Error processing request to Mistral model: {e}")
            time.sleep(20)  # Adjust sleep time as needed

def get_dialogue_res(knowledge, dialog, response1, response2, instruction):
    message = [
        {"role": "system", "content": "You are a response judge. You MUST select a response from the provided two responses. Your choice MUST be \"The best response is Response 1.\" or \"The best response is Response 2.\""},
        {"role": "user", "content": instruction +
                              "\n\n#Knowledge#: " + knowledge +
                              "\n#Dialogue History#: " + dialog +
                              "\n#Response 1#: " + response1 +
                              "\n#Response 2#: " + response2 +
                              "\n#Your Choice#: "}
    ]

    while True:
        try:
            res = call_mistral_model(message)
            if res:
                return res['choices'][0]['message']['content']
            else:
                return "Error: No response from Mistral model"
        except Exception as e:
            print(f"Error processing request to Mistral model: {e}")
            time.sleep(20)  # Adjust sleep time as needed

def get_summarization_res(document, summary1, summary2, instruction):
    message = [
        {"role": "system", "content": "You are a summary judge. You MUST select a summary from the provided two summaries. Respond ONLY with: \"The best summary is Summary 1.\" or \"The best summary is Summary 2.\""},
        {"role": "user", "content": instruction +
                              "\n\n#Document#: " + document +
                              "\n#Summary 1#: " + summary1 +
                              "\n#Summary 2#: " + summary2 +
                              "\n#Your Choice#: "}
    ]

    while True:
        try:
            res = call_mistral_model(message)
            if res:
                return res['choices'][0]['message']['content'].strip()
            else:
                return "Error: No response from Mistral model"
        except Exception as e:
            print(f"Error processing request to Mistral model: {e}")
            time.sleep(20)


def dump_jsonl(data, output_path, append=False):
    """
    Write list of objects to a JSON lines file.
    """
    mode = 'a+' if append else 'w'
    with open(output_path, mode, encoding='utf-8') as f:
        json_record = json.dumps(data, ensure_ascii=False)
        f.write(json_record + '\n')


def filtering_qa_dataset(file1, file2, instruction, output_path):
    with open(file1, 'r', encoding="utf-8") as f:
        data1 = [json.loads(line) for line in f]

    with open(file2, 'r', encoding="utf-8") as f:
        data2 = [json.loads(line) for line in f]

    print(f"Length of data1: {len(data1)}")
    print(f"Length of data2: {len(data2)}")

    min_length = min(len(data1), len(data2))

    for i in range(min_length):
        entry1 = data1[i]
        entry2 = data2[i]
        knowledge = entry1["knowledge"]
        question = entry1["question"]
        answer1 = entry1["hallucinated_answer"]
        answer2 = entry2["hallucinated_answer"]
        right_ans = entry1["right_answer"]

        # Initialize `ans` with a fallback value
        ans = "The best answer is Answer 2."

        if answer1 != answer2:
            k = 0
            while k < 5:
                ans = get_qa_res(knowledge, question, answer1, answer2, instruction)
                if "The best answer is Answer 1" in ans or "The best answer is Answer 2" in ans:
                    break
                k += 1
            else:
                print(f"Sample {i} failed after 5 attempts, using Answer 2 as default")

        if "1" in ans:
            answer = {"knowledge": knowledge, "question": question, "right_answer": right_ans, "hallucinated_answer": answer1}
        elif "2" in ans:
            answer = {"knowledge": knowledge, "question": question, "right_answer": right_ans, "hallucinated_answer": answer2}
        else:
            answer = {"knowledge": knowledge, "question": question, "right_answer": right_ans, "hallucinated_answer": answer2}
        
        dump_jsonl(answer, output_path, append=True)
        print(f"Sample {i} completed!")



def filtering_dialogue_dataset(file1, file2, instruction, output_path):
    with open(file1, 'r', encoding="utf-8") as f:
        data1 = [json.loads(line) for line in f]

    with open(file2, 'r', encoding="utf-8") as f:
        data2 = [json.loads(line) for line in f]

    print(f"Length of data1: {len(data1)}")
    print(f"Length of data2: {len(data2)}")

    min_length = min(len(data1), len(data2))

    for i in range(min_length):
        entry1 = data1[i]
        entry2 = data2[i]
        knowledge = entry1["knowledge"]
        dialog = entry1["dialogue_history"]
        right_response = entry1["right_response"]
        response1 = entry1["hallucinated_response"]
        response2 = entry2["hallucinated_response"]

        if response1 == response2:
            res = random.choice(["The best response is Response 1.", "The best response is Response 2."])
        else:
            k = 0
            res = ""
            while k < 5:
                try:
                    res = get_summarization_res(document, summary1, summary2, instruction)
                    print(f"Sample {i} try {k+1} response: {res}")
                    if "summary 1" in res.lower():
                        res = "The best summary is Summary 1."
                        break
                    elif "summary 2" in res.lower():
                        res = "The best summary is Summary 2."
                        break
                except Exception as e:
                    print(f"Error in summarization response: {e}")
                time.sleep(5)
                k += 1
            else:
                print(f"Sample {i} failed after 5 attempts, using Summary 2 as default")
                res = "The best summary is Summary 2."


        if "1" in res:
            answer = {"knowledge": knowledge, "dialogue_history": dialog, "right_response": right_response, "hallucinated_response": response1}
        elif "2" in res:
            answer = {"knowledge": knowledge, "dialogue_history": dialog, "right_response": right_response, "hallucinated_response": response2}
        else:
            answer = {"knowledge": knowledge, "dialogue_history": dialog, "right_response": right_response, "hallucinated_response": "failed!"}

        dump_jsonl(answer, output_path, append=True)
        print(f"Sample {i} completed!")

def filtering_summarization_dataset(file1, file2, instruction, output_path):
    with open(file1, 'r', encoding="utf-8") as f:
        data1 = [json.loads(line) for line in f]

    with open(file2, 'r', encoding="utf-8") as f:
        data2 = [json.loads(line) for line in f]

    print(f"Length of data1: {len(data1)}")
    print(f"Length of data2: {len(data2)}")

    min_length = min(len(data1), len(data2))

    for i in range(min_length):
        entry1 = data1[i]
        entry2 = data2[i]
        document = entry1["document"]
        summary1 = entry1["hallucinated_summary"]
        summary2 = entry2["hallucinated_summary"]
        right_summary = entry1["right_summary"]

        # Skip if summaries are exactly the same
        if summary1 == summary2:
            res = random.choice(["The best summary is Summary 1.", "The best summary is Summary 2."])
        else:
            k = 0
            res = ""
            while k < 5:
                try:
                    res = get_summarization_res(document, summary1, summary2, instruction)
                    print(f"Sample {i} try {k+1} response: {res}")
                    if "summary 1" in res.lower():
                        res = "The best summary is Summary 1."
                        break
                    elif "summary 2" in res.lower():
                        res = "The best summary is Summary 2."
                        break
                except Exception as e:
                    print(f"Error in summarization response: {e}")
                time.sleep(5)
                k += 1
            else:
                print(f"Sample {i} failed after 5 attempts, moving to next sample")
                continue

        if "summary 1" in res.lower():
            answer = {
                "document": document,
                "right_summary": right_summary,
                "hallucinated_summary": summary1
            }
        elif "summary 2" in res.lower():
            answer = {
                "document": document,
                "right_summary": right_summary,
                "hallucinated_summary": summary2
            }
        else:
            answer = {
                "document": document,
                "right_summary": right_summary,
                "hallucinated_summary": "failed!"
            }


        dump_jsonl(answer, output_path, append=True)
        print(f"Sample {i} completed!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Filtering dataset based on model output")
    parser.add_argument("--file1", type=str, required=True, help="Path to the first input file")
    parser.add_argument("--file2", type=str, required=True, help="Path to the second input file")
    parser.add_argument("--instruction", type=str, required=True, help="Instruction for the model")
    parser.add_argument("--output_path", type=str, required=True, help="Path to the output file")
    parser.add_argument("--task_type", type=str, required=True, choices=["qa", "dialogue", "summarization"], help="Type of task: qa, dialogue, or summarization")

    args = parser.parse_args()

    if args.task_type == "qa":
        filtering_qa_dataset(args.file1, args.file2, args.instruction, args.output_path)
    elif args.task_type == "dialogue":
        filtering_dialogue_dataset(args.file1, args.file2, args.instruction, args.output_path)
    elif args.task_type == "summarization":
        filtering_summarization_dataset(args.file1, args.file2, args.instruction, args.output_path)
